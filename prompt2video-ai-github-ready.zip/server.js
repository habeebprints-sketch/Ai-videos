// Node.js backend starter.
// IMPORTANT: Keep your AI provider API key on the server.
// Never put a secret API key inside index.html or app.js.

const express = require("express");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(__dirname));

app.post("/api/generate", async (req, res) => {
  const { prompt, url, duration, aspectRatio } = req.body;

  if (!prompt && !url) {
    return res.status(400).json({ error: "Prompt or URL is required." });
  }

  /*
    CONNECT YOUR VIDEO AI PROVIDER HERE.

    Example flow:
    1. If URL exists, fetch/parse the public webpage on your server.
    2. Turn the useful webpage text into a video script.
    3. Send the script/prompt to your chosen AI video API.
    4. Poll the provider until rendering is complete.
    5. Return the provider's final MP4 URL.

    Do NOT expose your provider secret in frontend JavaScript.

    Example response expected by app.js:
    {
      "videoUrl": "https://your-storage.example/video.mp4"
    }
  */

  return res.status(501).json({
    error: "Video API is not connected yet. Add your AI video provider in server.js."
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Prompt2Video AI running on http://localhost:${PORT}`);
});
