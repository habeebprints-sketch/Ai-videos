const API = "/api/generate";

const prompt = document.getElementById("prompt");
const url = document.getElementById("url");
const duration = document.getElementById("duration");
const format = document.getElementById("format");
const button = document.getElementById("generate");
const message = document.getElementById("message");
const result = document.getElementById("result");
const video = document.getElementById("video");
const download = document.getElementById("download");

button.addEventListener("click", async () => {
  if (!prompt.value.trim() && !url.value.trim()) {
    message.textContent = "Enter a video prompt or a website URL.";
    return;
  }

  button.disabled = true;
  message.textContent = "Creating your video...";

  try {
    const response = await fetch(API, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        prompt: prompt.value.trim(),
        url: url.value.trim(),
        duration: Number(duration.value),
        aspectRatio: format.value
      })
    });

    const data = await response.json();

    if (!response.ok) throw new Error(data.error || "Generation failed.");

    // The backend should return a completed video URL.
    video.src = data.videoUrl;
    download.href = data.videoUrl;
    result.classList.remove("hidden");
    message.textContent = "Video ready!";
  } catch (error) {
    message.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});
